# we save all timezone with TZIDs unknown to the TZDB in here
_timezone_cache = {}
